
const url = require('url');

const getImage = (request, response) => {
  var request = url.parse(req.url, true);
  const action = request.pathname;
  const img = fs.readFileSync('../client/spongegar.png');
  res.writeHead(200, { 'Content-Type': 'image/png' });
  res.end(img, 'binary');
};

module.exports.getImage = getImage;
